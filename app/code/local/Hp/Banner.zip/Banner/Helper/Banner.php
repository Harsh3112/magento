<?php

class Hp_Banner_Helper_Banner extends Mage_Core_Helper_Abstract
{

	public function __construct()
	{
	}
}
