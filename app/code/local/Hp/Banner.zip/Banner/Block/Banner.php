<?php

class Hp_Banner_Block_Banner extends Mage_Core_Block_Template
{
    function __construct()
    {
        parent::__construct();
    }

}
